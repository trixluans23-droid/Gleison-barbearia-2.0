# Gleison Barbearia 2.0

Projeto Android inicial do novo aplicativo.

- Pacote: `com.gleisonbarbearia.app`
- Firebase Cloud Messaging configurado
- Notificações Android com som/vibração
- Canal de alta prioridade
- Permissão de notificações no Android 13+

Nenhum HTML do projeto antigo é usado neste projeto.
